#include <string>

#include "format.h"

/**
 * INPUT: Long int measuring seconds
 * OUTPUT: HH:MM:SS
 */
std::string Format::ElapsedTime(long seconds) { 
    int hour, minute, second;
    second = int(seconds % 60);
    minute = int(seconds / 60);
    hour = int(minute / 60);
    return std::to_string(hour) + ":" + std::to_string(minute % 60) + ":" + std::to_string(second); 
}